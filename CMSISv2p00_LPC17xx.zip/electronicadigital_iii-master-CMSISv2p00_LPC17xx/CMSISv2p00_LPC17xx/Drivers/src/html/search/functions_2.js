var searchData=
[
  ['pinsel_5fconfigpin_104',['PINSEL_ConfigPin',['../group__PINSEL__Public__Functions.html#ga771fcbed8f7ee806292e06e283611dc9',1,'lpc17xx_pinsel.c']]],
  ['pinsel_5fconfigtracefunc_105',['PINSEL_ConfigTraceFunc',['../group__PINSEL__Public__Functions.html#ga9a48ea7b433ed1a2cb149627cf5c7c6b',1,'lpc17xx_pinsel.c']]],
  ['pinsel_5fseti2c0pins_106',['PINSEL_SetI2C0Pins',['../group__PINSEL__Public__Functions.html#gacb6281f39ff79f79e9c29487f89a8b33',1,'lpc17xx_pinsel.c']]]
];
